#!/usr/bin/env python3
# streamlit_entry.py  – interfaz Streamlit (Playwright)
# v1.1  (-zip solo del merchant)

import subprocess, sys, datetime, zipfile, re
from pathlib import Path
from typing import List, Tuple

import streamlit as st
import importlib.resources as pkg_resources


# ────────────────────────── Ajustes UI ──────────────────────────────
st.set_page_config(page_title="Extractor de menús iFood",
                   layout="centered")
st.title("🍽️  Extractor de menús iFood")


# ───────────────────────── helper run_command ───────────────────────
def run_command(cmd: List[str], cwd: Path) -> Tuple[str, int]:
    placeholder = st.empty()
    lines: List[str] = []
    proc = subprocess.Popen(
        cmd, cwd=cwd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )
    assert proc.stdout
    for line in proc.stdout:
        lines.append(line.rstrip())
        placeholder.code("\n".join(lines[-300:]))
    proc.wait()
    return "\n".join(lines), proc.returncode


# ─────────────────────── extract_merchant_id ────────────────────────
def extract_merchant_id(url: str) -> str | None:
    m = re.search(r"([a-f0-9\-]{36})(?:$|/|\?)", url)
    return m.group(1) if m else None


# ───────────────────────────────── main ─────────────────────────────
def main() -> None:
    url = st.text_input("URL del restaurante iFood")

    # Caja donde el usuario escribe SOLO el nombre de la carpeta base
    carpeta_out = st.text_input(
        "Carpeta base de salida (se creará dentro del workspace de Streamlit):",
        value="salida"
    )

    if not st.button("Iniciar proceso"):
        return
    if not url.strip():
        st.warning("Debes introducir una URL.")
        st.stop()

    merchant_id = extract_merchant_id(url)
    if not merchant_id:
        st.error("No se pudo extraer merchant_id de la URL.")
        st.stop()

    # ─────────────────────────── Paths ──────────────────────────────
    workspace_root = Path.cwd()                  # raíz del contenedor Streamlit
    safe_name      = Path(carpeta_out).name or "salida"
    out_base       = (workspace_root / safe_name).resolve()
    out_base.mkdir(parents=True, exist_ok=True)

    run_dir = out_base / merchant_id             # <salida>/<UUID>
    run_dir.mkdir(parents=True, exist_ok=True)

    # ubicación de los scripts empaquetados
    from ifoodextractor import scripts
    scripts_path = Path(pkg_resources.files(scripts))

    st.info(f"Guardando resultados en: {run_dir.as_posix()}")

    # ─────────────────────────── Paso 1 ─────────────────────────────
    cmd1 = [sys.executable, str(scripts_path / "01_extraer_catalogo.py"),
            "--url", url, "--out_dir", str(out_base)]
    _, rc = run_command(cmd1, scripts_path)
    if rc:
        st.error("Error en paso 1"); st.stop()

    # ─────────────────────────── Paso 2 ─────────────────────────────
    cmd2 = [sys.executable, str(scripts_path / "02_descargar_imagenes.py"),
            "--url", url, "--out_dir", str(out_base), "--headless"]
    _, rc = run_command(cmd2, scripts_path)
    if rc:
        st.error("Error en paso 2"); st.stop()

    # ─────────────────────────── Paso 3 ─────────────────────────────
    cmd3 = [sys.executable, str(scripts_path / "03_unir_imagenes_excel.py"),
            "--url", url, "--out_dir", str(out_base)]
    _, rc = run_command(cmd3, scripts_path)
    if rc:
        st.error("Error en paso 3"); st.stop()

    # ─────────────────────────── ZIP ────────────────────────────────
    ts = datetime.datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    zip_path = out_base / f"ifood_extract_{merchant_id}_{ts}.zip"

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in run_dir.rglob("*"):
            zf.write(f, f.relative_to(run_dir))

    st.success("¡Proceso completado!")
    st.download_button(
        "Descargar resultados",
        zip_path.read_bytes(),
        file_name=zip_path.name,
        mime="application/zip"
    )


# ────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    main()