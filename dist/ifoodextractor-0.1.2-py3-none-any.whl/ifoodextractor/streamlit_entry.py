#!/usr/bin/env python3
# streamlit_entry.py  – versión completa y corregida (jun-2024)

import subprocess
import sys
import datetime
import zipfile
from pathlib import Path
from typing import List, Tuple

import streamlit as st
import importlib.resources as pkg_resources
from ifoodextractor import scripts  # sub-paquete con los 3 scripts

# ───────────────────────────  Config UI  ────────────────────────────
st.set_page_config(
    page_title="Extractor de menús iFood",
    layout="centered",
    initial_sidebar_state="auto",
)

st.title("🍽️  Extractor de menús iFood")


# ─────────────────────── helper para subprocesos ─────────────────────
def run_command(cmd: List[str], working_dir: Path) -> Tuple[str, int]:
    """
    Ejecuta un comando y va mostrando la salida en tiempo real.
    Devuelve (stdout_completo, return_code).
    """
    placeholder = st.empty()
    lines: List[str] = []

    proc = subprocess.Popen(
        cmd,
        cwd=working_dir,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )

    assert proc.stdout is not None
    for line in proc.stdout:
        lines.append(line.rstrip())
        # sólo enseñamos las últimas 300 líneas
        placeholder.code("\n".join(lines[-300:]))

    proc.wait()
    return "\n".join(lines), proc.returncode


# ─────────────────────────────  MAIN  ────────────────────────────────
def main() -> None:

    IN_CLOUD = (os.getenv("STREAMLIT_EXECUTION_ENV", "").lower() == "cloud")
    if IN_CLOUD:
        run_selenium = False          # fuerza la casilla a off

    # ---------- Widgets ------------------------------------------------
    url: str = st.text_input("URL del restaurante iFood")
    out_dir: str = st.text_input(
        "Carpeta base de salida (se creará dentro del workspace):",
        value="salida",
    )
    run_selenium: bool = st.checkbox(
        "Usar Selenium como último recurso para imágenes",
        value=False,
        help="En Streamlit Cloud no hay Chrome; esta opción solo sirve en local.",
    )

    if not st.button("Iniciar proceso"):
        return

    if not url.strip():
        st.warning("Debes introducir una URL válida.")
        st.stop()

    # ---------- Carpeta base absoluta con permisos de escritura -------
    OUT_BASE = Path(out_dir).expanduser().resolve()
    OUT_BASE.mkdir(parents=True, exist_ok=True)

    # ---------- Localizar scripts dentro del paquete ------------------
    scripts_path = Path(pkg_resources.files(scripts))
    st.info(f"Scripts localizados en: {scripts_path.as_posix()}")

    # ------------------------------------------------------------------
    # Paso 1 – Catálogo
    # ------------------------------------------------------------------
    st.markdown("### 1️⃣  Extrayendo catálogo …")
    cmd1 = [
        sys.executable,
        str(scripts_path / "01_extraer_catalogo.py"),
        "--url", url,
        "--out_dir", str(OUT_BASE),
    ]
    _, rc = run_command(cmd1, Path.cwd())
    if rc != 0:
        st.error("Fallo en 01_extraer_catalogo.py")
        st.stop()

    # ------------------------------------------------------------------
    # Paso 2 – Imágenes
    # ------------------------------------------------------------------
    st.markdown("### 2️⃣  Descargando imágenes …")
    cmd2 = [
        sys.executable,
        str(scripts_path / "02_descargar_imagenes.py"),
        "--url", url,
        "--out_dir", str(OUT_BASE),
        "--headless",
    ]
    if not run_selenium:
        cmd2.append("--skip_selenium")

    _, rc = run_command(cmd2, Path.cwd())
    if rc != 0:
        st.error("Fallo en 02_descargar_imagenes.py")
        st.stop()

    # ------------------------------------------------------------------
    # Paso 3 – Excel final
    # ------------------------------------------------------------------
    st.markdown("### 3️⃣  Generando Excel final …")
    cmd3 = [
        sys.executable,
        str(scripts_path / "03_unir_imagenes_excel.py"),
        "--url", url,
        "--out_dir", str(OUT_BASE),
    ]
    _, rc = run_command(cmd3, Path.cwd())
    if rc != 0:
        st.error("Fallo en 03_unir_imagenes_excel.py")
        st.stop()

    # ------------------------------------------------------------------
    # Paso 4 – Empaquetar resultados
    # ------------------------------------------------------------------
    st.markdown("### 📦  Empaquetando resultados …")
    timestamp = datetime.datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    zip_name = f"ifood_extract_{timestamp}.zip"
    zip_path = OUT_BASE / zip_name

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for file in OUT_BASE.rglob("*"):
            if file == zip_path:
                continue
            zf.write(file, file.relative_to(OUT_BASE))

    st.success("Proceso completado con éxito 🎉")
    st.download_button(
        label="Descargar resultados (.zip)",
        data=zip_path.read_bytes(),
        file_name=zip_name,
        mime="application/zip",
    )


# ───────────────────────────  entry-point  ───────────────────────────
if __name__ == "__main__":
    main()