#!/usr/bin/env python3
# util_coords.py   (sin cambios funcionales)

from __future__ import annotations
import re
import sys
from typing import Tuple
import requests

USER_AGENT = "Mozilla/5.0"
TIMEOUT = 30
REGEX_LAT = r'"latitude"\s*:\s*([-]?\d+\.\d+)'
REGEX_LON = r'"longitude"\s*:\s*([-]?\d+\.\d+)'

def descargar_html(url: str) -> str:
    r = requests.get(url, headers={"User-Agent": USER_AGENT}, timeout=TIMEOUT)
    r.raise_for_status()
    return r.text

def extraer_coordenadas(html: str) -> Tuple[float, float]:
    m_lat = re.search(REGEX_LAT, html)
    m_lon = re.search(REGEX_LON, html)
    if not (m_lat and m_lon):
        raise ValueError("No se encontraron coordenadas en el HTML")
    return float(m_lat.group(1)), float(m_lon.group(1))

def extract_merchant_id(url: str) -> str:
    return url.rstrip("/").split("/")[-1]

def get_coords(url: str) -> Tuple[str, float, float]:
    html = descargar_html(url)
    lat, lon = extraer_coordenadas(html)
    merchant_id = extract_merchant_id(url)
    return merchant_id, lat, lon

def _main() -> None:
    url = sys.argv[1].strip() if len(sys.argv) >= 2 else input("Introduce la URL del restaurante: ").strip()
    if not url:
        print("No se proporcionó URL.")
        sys.exit(1)
    try:
        merchant_id, lat, lon = get_coords(url)
    except Exception as e:
        print("Error:", e)
        sys.exit(1)
    print("merchant_id:", merchant_id)
    print("latitude   :", lat)
    print("longitude  :", lon)

if __name__ == "__main__":
    _main()