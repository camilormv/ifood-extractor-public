#!/usr/bin/env python3
# 01_extraer_catalogo.py  v0.1.4

from __future__ import annotations
import json, re, argparse, requests, pandas as pd
from pathlib import Path
from urllib.parse import urlparse, unquote
from ifoodextractor.scripts.util_coords import descargar_html, extraer_coordenadas

# ─── helpers ─────────────────────────────────────────────────────────
def log(msg: str, logfile: Path) -> None:
    print(msg)
    logfile.write_text((logfile.read_text("utf-8") if logfile.exists() else "")
                       + msg + "\n", encoding="utf-8")

def extract_merchant_id(url: str) -> str | None:
    m = re.search(r"([a-f0-9\-]{36})(?:$|/|\?)", url)
    return m.group(1) if m else None

def obtener_slug(full_url: str) -> str:
    segs = [s for s in unquote(urlparse(full_url).path).split("/") if s]
    return segs[-2] if len(segs) >= 2 else "desconocido"

def primera_no_vacia(*vals):       # devuelve el primer argumento truthy
    return next((v for v in vals if v), None)
# ─────────────────────────────────────────────────────────────────────

def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--url", required=True)
    p.add_argument("--out_dir", default="salida")
    args = p.parse_args()

    OUT_BASE = Path(args.out_dir).expanduser().resolve()
    url = args.url
    merchant_id = extract_merchant_id(url) or exit("merchant_id no encontrado")
    OUT_DIR = OUT_BASE / merchant_id
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    logfile = OUT_DIR / "log_01.txt"

    html = descargar_html(url)
    lat, lon = extraer_coordenadas(html)
    log(f"coords: {lat},{lon}", logfile)

    headers = {
        "accept": "application/json, text/plain, */*",
        "user-agent": "Mozilla/5.0",
        "x-client-application-key": "41a266ee-51b7-4c37-9e9d-5cd331f280d5",
        "x-ifood-device-id": "69d8742f-f8cc-4c85-a24a-d5c0fdd8ea1f",
        "x-ifood-session-id": "a76ed1e4-5406-4e3e-96a6-869551577cf5",
        "referer": "https://www.ifood.com.br/",
    }
    api_url = f"https://marketplace.ifood.com.br/v1/merchants/{merchant_id}/catalog"
    catalog = requests.get(api_url, params={"latitude": lat, "longitude": lon},
                           headers=headers, timeout=30).json()
    (OUT_DIR / "catalog_raw.json").write_text(
        json.dumps(catalog, ensure_ascii=False, indent=2), encoding="utf-8")

    with (OUT_DIR / "info_negocio.txt").open("w", encoding="utf-8") as f:
        f.write(f"restaurant_slug: {obtener_slug(url)}\n")
        f.write(f"merchant_id:     {merchant_id}\n")
        f.write(f"latitude:        {lat}\nlongitude:       {lon}\nurl: {url}\n")

    rows_prod, rows_opt = [], []
    for cat in catalog["data"]["menu"]:
        for item in cat["itens"]:
            img_url = primera_no_vacia(
                item.get("logoUrl"), item.get("imageUrl"), item.get("photoUrl"),
                item.get("imagePath"),
                (item.get("images", [{}])[0].get("path") if isinstance(item.get("images"), list) and item["images"] else None)
            )
            rows_prod.append({
                "category_code": cat["code"], "category": cat["name"],
                "product_id": item["id"], "product_code": item["code"],
                "product_name": item["description"], "details": item.get("details"),
                "need_choices": item.get("needChoices"), "price": item.get("unitPrice"),
                "api_image_url": img_url
            })
            for ch in item.get("choices", []):
                for op in ch.get("garnishItens", []):
                    img_url_opc = primera_no_vacia(
                        op.get("logoUrl"), op.get("imageUrl"), op.get("photoUrl"),
                        op.get("imagePath"),
                        (op.get("images", [{}])[0].get("path") if isinstance(op.get("images"), list) and op["images"] else None)
                    )
                    rows_opt.append({
                        "product_id": item["id"], "product_name": item["description"],
                        "group": ch.get("name", ""), "option_id": op.get("id"),
                        "option_code": op.get("code", ""), "option_name": op.get("description"),
                        "option_price": op.get("unitPrice"), "option_image_url": img_url_opc
                    })

    import pandas as pd
    pd.DataFrame(rows_prod).to_csv(OUT_DIR / "menu_productos_base.csv", index=False)
    if rows_opt:
        pd.DataFrame(rows_opt).to_csv(OUT_DIR / "menu_opciones_base.csv", index=False)
    log("01_extraer_catalogo completado", logfile)

if __name__ == "__main__":
    main()