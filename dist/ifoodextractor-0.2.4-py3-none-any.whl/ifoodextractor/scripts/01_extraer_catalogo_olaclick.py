#!/usr/bin/env python3
# 01_extraer_catalogo_olaclick.py

import argparse, requests, re, json
from pathlib import Path
import pandas as pd

def get_company_id_from_slug(slug: str) -> str | None:
    # Carga HTML inicial y busca el UUID company_id (usando expresión regular).
    url = f"https://{slug}.ola.click/products"
    html = requests.get(url).text
    m = re.search(r'"companyId"\s*:\s*"([a-f0-9\-]+)"', html)
    if m:
        return m.group(1)
    print("No se pudo encontrar el companyId en el HTML.")
    return None

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--url", required=True)
    p.add_argument("--out_dir", default="salida")
    args = p.parse_args()

    url = args.url
    slug_match = re.search(r"//([a-z0-9\-]+)\.ola\.click", url.lower())
    if not slug_match:
        print("URL no válida de OlaClick.")
        exit(1)
    slug = slug_match.group(1)

    company_id = get_company_id_from_slug(slug)
    if not company_id:
        exit(1)

    OUT_BASE = Path(args.out_dir).expanduser().resolve()
    OUT_DIR = OUT_BASE / slug
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    logfile = OUT_DIR / "log_01.txt"

    api_url = f"https://public-api.olaclick.app/ms-products/public/companies/{company_id}/categories"
    headers = {
        'accept': "application/json, text/plain, */*",
        'origin': f"https://{slug}.ola.click",
        'referer': f"https://{slug}.ola.click/",
        'user-agent': "Mozilla/5.0"
    }
    resp = requests.get(api_url, headers=headers)
    if resp.status_code != 200:
        print(f"Error consultando API: {resp.status_code}")
        exit(1)
    catalog = resp.json()
    (OUT_DIR / "catalog_raw.json").write_text(json.dumps(catalog, indent=2, ensure_ascii=False), encoding="utf-8")

    with (OUT_DIR / "info_negocio.txt").open("w", encoding="utf-8") as f:
        f.write(f"olaclick_slug: {slug}\n")
        f.write(f"company_id:   {company_id}\n")
        f.write(f"url: {url}\n")

    rows_prod, rows_opt = [], []
    for category in catalog:
        cat_id = category.get("id")
        cat_name = category.get("name")
        for prod in category.get("products", []):
            img_url = prod.get("mainImage", {}).get("url")
            rows_prod.append({
                "category_id": cat_id,
                "category": cat_name,
                "product_id": prod.get("id"),
                "product_name": prod.get("name"),
                "details": prod.get("description"),
                "price": prod.get("price"),
                "api_image_url": img_url
            })
            # Adaptar si encuentras campos de opciones/toppings en la estructura de OlaClick:
            toppings = prod.get("toppings", [])
            for topping in toppings:
                for option in topping.get("options", []):
                    rows_opt.append({
                        "product_id": prod.get("id"),
                        "product_name": prod.get("name"),
                        "group": topping.get("name"),
                        "option_id": option.get("id"),
                        "option_name": option.get("name"),
                        "option_price": option.get("price"),
                        "option_image_url": option.get("image", {}).get("url")
                    })

    pd.DataFrame(rows_prod).to_csv(OUT_DIR / "menu_productos_base.csv", index=False)
    if rows_opt:
        pd.DataFrame(rows_opt).to_csv(OUT_DIR / "menu_opciones_base.csv", index=False)

    print("01_extraer_catalogo_olaclick.py completado")

if __name__ == "__main__":
    main()