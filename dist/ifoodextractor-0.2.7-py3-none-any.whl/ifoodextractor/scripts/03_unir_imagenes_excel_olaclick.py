#!/usr/bin/env python3
# 03_unir_imagenes_excel_olaclick.py

import pandas as pd
import json
import argparse
from pathlib import Path
import re
import sys

def log(msg: str, logfile: Path) -> None:
    try:
        print(msg)
    except UnicodeEncodeError:
        safe = msg.encode("ascii", errors="ignore").decode("ascii")
        print(safe)
    with logfile.open("a", encoding="utf-8") as f:
        f.write(msg + "\n")

def extract_olaclick_slug(url: str) -> str | None:
    m = re.search(r'//([a-z0-9\-]+)\.ola\.click', url)
    return m.group(1) if m else None

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--url",     type=str, help="URL de la tienda OlaClick")
    parser.add_argument("--out_dir", type=str, default="salida",
                        help="Carpeta base donde se guardará la salida")
    args = parser.parse_args()

    url = args.url or input("Pega la URL de la tienda OlaClick: ").strip()
    slug = extract_olaclick_slug(url)
    if not slug:
        print("No pude extraer slug de la URL OlaClick.")
        sys.exit(1)

    OUT_DIR = Path(args.out_dir) / slug
    logfile  = OUT_DIR / "log_03.txt"

    csv_path          = OUT_DIR / "menu_productos_base.csv"
    img_json_path     = OUT_DIR / "paths_img.json"
    opciones_csv_path = OUT_DIR / "menu_opciones_base.csv"
    opt_img_json_path = OUT_DIR / "paths_img_opciones.json"

    if not csv_path.exists() or not img_json_path.exists():
        print("Faltan archivos previos. Corre primero los scripts 01 y 02.")
        sys.exit(1)

    df_prod = pd.read_csv(csv_path, encoding="utf-8")
    with img_json_path.open(encoding="utf-8") as f:
        img_paths = json.load(f)

    df_prod["local_image_path"] = df_prod["product_id"].astype(str).map(img_paths)
    df_prod.to_excel(OUT_DIR / "menu_productos_con_imagen.xlsx", index=False)
    log("[OK] menu_productos_con_imagen.xlsx listo.", logfile)

    if opciones_csv_path.exists():
        df_opt = pd.read_csv(opciones_csv_path, encoding="utf-8")
        if opt_img_json_path.exists():
            with opt_img_json_path.open(encoding="utf-8") as f:
                opc_img_paths = json.load(f)
            df_opt["local_image_path"] = df_opt["option_id"].astype(str).map(opc_img_paths)
        else:
            df_opt["local_image_path"] = None

        df_opt.to_excel(OUT_DIR / "menu_opciones_con_imagen.xlsx", index=False)
        log("[OK] menu_opciones_con_imagen.xlsx listo.", logfile)
    else:
        log("[INFO] No existe menu_opciones_base.csv; se omite exportación de opciones.", logfile)

    log("Script 03_unir_imagenes_excel_olaclick finalizado.\n", logfile)

if __name__ == "__main__":
    main()