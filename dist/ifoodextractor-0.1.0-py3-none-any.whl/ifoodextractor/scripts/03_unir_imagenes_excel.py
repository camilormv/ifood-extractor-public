#!/usr/bin/env python3
# 03_unir_imagenes_excel.py  – versión compatible con CP-1252 / Windows

import pandas as pd
import json
import argparse
from pathlib import Path
import re
import sys

# ───────────────────────── helper log() ────────────────────────────
def log(msg: str, logfile: Path) -> None:
    """
    Imprime el mensaje en pantalla y lo guarda en un fichero.
    Si la consola no soporta UTF-8 (p.e. Windows/CP-1252) se elimina
    cualquier carácter que provoque UnicodeEncodeError.
    """
    try:
        print(msg)
    except UnicodeEncodeError:
        # re-imprime sin caracteres no ASCII
        safe = msg.encode("ascii", errors="ignore").decode("ascii")
        print(safe)

    with logfile.open("a", encoding="utf-8") as f:
        f.write(msg + "\n")
# ────────────────────────────────────────────────────────────────────

def extract_merchant_id(url: str) -> str | None:
    m = re.search(r'([a-f0-9\-]{36})(?:$|/|\?)', url)
    return m.group(1) if m else None

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--url",     type=str, help="URL de la tienda iFood")
    parser.add_argument("--out_dir", type=str, default="salida",
                        help="Carpeta base donde se guardará la salida")
    args = parser.parse_args()

    url = args.url or input("Pega la URL de la tienda ifood: ").strip()
    merchant_id = extract_merchant_id(url)
    if not merchant_id:
        print("No pude extraer merchant_id de la URL.")
        sys.exit(1)

    OUT_DIR = Path(args.out_dir) / merchant_id
    logfile  = OUT_DIR / "log_03.txt"

    csv_path          = OUT_DIR / "menu_productos_base.csv"
    img_json_path     = OUT_DIR / "paths_img.json"
    opciones_csv_path = OUT_DIR / "menu_opciones_base.csv"
    opt_img_json_path = OUT_DIR / "paths_img_opciones.json"

    # ---------- Productos principales ---------------------------------
    if not csv_path.exists() or not img_json_path.exists():
        print("Faltan archivos previos. Corre primero los scripts 01 y 02.")
        sys.exit(1)

    df_prod = pd.read_csv(csv_path, encoding="utf-8")
    with img_json_path.open(encoding="utf-8") as f:
        img_paths = json.load(f)

    df_prod["local_image_path"] = df_prod["product_code"].astype(str).map(img_paths)
    df_prod.to_excel(OUT_DIR / "menu_productos_con_imagen.xlsx", index=False)
    log("[OK] menu_productos_con_imagen.xlsx listo.", logfile)

    # ---------- Opciones / toppings -----------------------------------
    if opciones_csv_path.exists():
        df_opt = pd.read_csv(opciones_csv_path, encoding="utf-8")
        if opt_img_json_path.exists():
            with opt_img_json_path.open(encoding="utf-8") as f:
                opc_img_paths = json.load(f)
            df_opt["local_image_path"] = df_opt["option_id"].astype(str).map(opc_img_paths)
        else:
            df_opt["local_image_path"] = None

        df_opt.to_excel(OUT_DIR / "menu_opciones_con_imagen.xlsx", index=False)
        log("[OK] menu_opciones_con_imagen.xlsx listo.", logfile)
    else:
        log("[INFO] No existe menu_opciones_base.csv; se omite exportación de opciones.", logfile)

    log("Script 03_unir_imagenes_excel finalizado.\n", logfile)

if __name__ == "__main__":
    main()