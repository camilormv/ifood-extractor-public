#!/usr/bin/env python3
# 02_descargar_imagenes_rappi.py  – descarga directa de imágenes de Rappi

import os
import re
import json
import argparse
from pathlib import Path

import pandas as pd
import requests

def log(msg: str, logfile: Path) -> None:
    """Log por pantalla y archivo."""
    try:  print(msg)
    except UnicodeEncodeError:
        print(msg.encode("ascii","ignore").decode())
    logfile.write_text(logfile.read_text("utf-8", errors="ignore")+msg+"\n",
                       encoding="utf-8", errors="ignore")

def safe_filename(txt, maxlen=60):
    return re.sub(r"[^\w\-. ]","_",str(txt))[:maxlen]

def extract_rappi_store_id(url: str) -> str|None:
    match = re.search(r'/restaurantes/(\d+)-', url)
    if match: return match.group(1)
    match = re.search(r'/restaurantes/(\d+)', url)
    if match: return match.group(1)
    return None

def download_image(url: str, dst: Path, timeout=25) -> bool:
    try:
        r = requests.get(url, headers={"User-Agent":"Mozilla/5.0"}, timeout=timeout)
        r.raise_for_status()
        dst.write_bytes(r.content)
        return True
    except Exception:
        return False

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", required=False)
    ap.add_argument("--out_dir", default="salida")
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--headless", action="store_true") # se ignora en Rappi, por compatibilidad
    args = ap.parse_args()

    url = args.url or input("URL Rappi: ").strip()
    store_id = extract_rappi_store_id(url)
    if not store_id:
        print("store_id no encontrado."); return

    OUT = Path(args.out_dir) / store_id
    IMG = OUT / "img";  IMG.mkdir(parents=True, exist_ok=True)
    logf = OUT / "log_02.txt"; logf.touch(exist_ok=True)

    df_prod = pd.read_csv(OUT / "menu_productos_base.csv", encoding="utf-8")
    if args.limit > 0: df_prod = df_prod.head(args.limit)

    log(f"Productos a procesar: {len(df_prod)}", logf)

    product_img_paths = {}

    # 1) Descarga directa desde la URL en el CSV
    for _, row in df_prod.iterrows():
        code = str(row.get("product_code"))
        name = str(row.get("product_name"))
        img_url = row.get("api_image_url")
        if not img_url or not isinstance(img_url, str) or not img_url.startswith("http"):
            continue
        ext = os.path.splitext(img_url)[1].split("?")[0] or ".jpg"
        dst = IMG / f"{safe_filename(code+'_'+name)}{ext}"
        if download_image(img_url, dst):
            product_img_paths[code] = str(dst)
        else:
            log(f"[WARN] fallo descarga: {code} {img_url}", logf)

    # Opciones (toppings, extras) — solo si existen
    opciones_csv_path = OUT / "menu_opciones_base.csv"
    opc_img_json_path = OUT / "paths_img_opciones.json"
    option_img_paths = {}

    if opciones_csv_path.exists():
        df_opt = pd.read_csv(opciones_csv_path, encoding="utf-8")
        for _, row in df_opt.iterrows():
            code = str(row.get("option_id"))
            name = str(row.get("option_name"))
            img_url = row.get("option_image_url")
            if not img_url or not isinstance(img_url, str) or not img_url.startswith("http"):
                continue
            ext = os.path.splitext(img_url)[1].split("?")[0] or ".jpg"
            dst = IMG / f"opc_{safe_filename(code+'_'+name)}{ext}"
            if download_image(img_url, dst):
                option_img_paths[code] = str(dst)
            else:
                log(f"[WARN] fallo descarga opc: {code} {img_url}", logf)
        if option_img_paths:
            opc_img_json_path.write_text(json.dumps(option_img_paths, ensure_ascii=False, indent=2), encoding="utf-8")

    # Guardar mapeo de productos
    (OUT / "paths_img.json").write_text(json.dumps(product_img_paths, ensure_ascii=False, indent=2), encoding="utf-8")

    log(f"Imágenes descargadas: {len(product_img_paths)} productos "
        f"| {len(option_img_paths)} opciones", logf)
    log("Script 02_descargar_imagenes_rappi finalizado.\n", logf)

if __name__ == "__main__":
    main()