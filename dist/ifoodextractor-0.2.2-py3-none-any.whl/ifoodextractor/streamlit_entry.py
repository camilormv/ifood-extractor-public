#!/usr/bin/env python3
# streamlit_entry.py – interfaz Streamlit (Playwright)
# v2.0 – Multi-plataforma iFood/Rappi

import subprocess, sys, datetime, zipfile, re, shutil
from pathlib import Path
from typing import List, Tuple

import streamlit as st
import importlib.resources as pkg_resources      #  ← alias que sí usamos

# ──────────────── helper para plataforma ───────────────
def detectar_plataforma(url: str) -> str:
    url = url.lower()
    if "ifood.com.br" in url:
        return "ifood"
    elif "rappi.com.br" in url:
        return "rappi"
    else:
        return "desconocida"

# ───────── Puerta de contraseña ──────────────
def password_gate() -> None:
    secret = st.secrets.get("APP_PASSWORD")
    if not secret:
        return
    if not st.session_state.get("auth_ok", False):
        pwd = st.text_input("Contraseña", type="password")
        if st.button("Entrar"):
            if pwd == secret:
                st.session_state["auth_ok"] = True
                (st.rerun() if hasattr(st, "rerun")
                            else st.experimental_rerun())
            else:
                st.error("Contraseña incorrecta")
        st.stop()

# ────── helper: salida subproceso ─────────────
def run_command(cmd: List[str], cwd: Path) -> Tuple[str, int]:
    ph = st.empty(); lines: List[str] = []
    p = subprocess.Popen(cmd, cwd=cwd,
                         stdout=subprocess.PIPE,
                         stderr=subprocess.STDOUT, text=True)
    assert p.stdout
    for line in p.stdout:
        lines.append(line.rstrip())
        ph.code("\n".join(lines[-300:]))
    p.wait()
    return "\n".join(lines), p.returncode

# ───────── helpers de id --------
def extract_ifood_merchant_id(url: str) -> str | None:
    m = re.search(r"([a-f0-9\-]{36})(?:$|/|\?)", url)
    return m.group(1) if m else None

def extract_rappi_store_id(url: str) -> str | None:
    match = re.search(r'/restaurantes/(\d+)-', url)
    if match: return match.group(1)
    match = re.search(r'/restaurantes/(\d+)', url)
    if match: return match.group(1)
    return None

# ────────────────────── main ──────────────────────
def main() -> None:
    password_gate()                           # pide contraseña si aplica

    st.set_page_config(page_title="Extractor de menús iFood/Rappi",
                       layout="centered")
    st.title("🍽️  Extractor de menús iFood / Rappi")

    url = st.text_input("URL del restaurante (iFood o Rappi)")

    if not st.button("Iniciar proceso"):
        return
    if not url.strip():
        st.warning("Debes introducir una URL."); st.stop()

    # Identifica la plataforma
    plataforma = detectar_plataforma(url)
    if plataforma == "ifood":
        merchant_id = extract_ifood_merchant_id(url)
        if not merchant_id:
            st.error("No se pudo extraer merchant_id de iFood."); st.stop()
        script_catalogo = "01_extraer_catalogo.py"
        script_imagenes = "02_descargar_imagenes.py"
        script_excel    = "03_unir_imagenes_excel.py"
        current_run_id = merchant_id
    elif plataforma == "rappi":
        store_id = extract_rappi_store_id(url)
        if not store_id:
            st.error("No se pudo extraer store_id de Rappi."); st.stop()
        script_catalogo = "01_extraer_catalogo_rappi.py"
        script_imagenes = "02_descargar_imagenes_rappi.py"
        script_excel    = "03_unir_imagenes_excel_rappi.py"
        current_run_id = store_id
    else:
        st.error("URL no reconocida como iFood ni Rappi."); st.stop()

    # ---------- Paths ----------
    workspace_root = Path.cwd()
    out_base = (workspace_root / "salida").resolve()
    if out_base.exists():
        shutil.rmtree(out_base)
    out_base.mkdir(parents=True, exist_ok=True)

    run_dir = out_base / current_run_id
    run_dir.mkdir(parents=True, exist_ok=True)

    # ubicación de los scripts empaquetados
    from ifoodextractor import scripts
    scripts_path = Path(pkg_resources.files(scripts))   # ← FIX aquí

    st.info(f"Guardando resultados en: {run_dir.as_posix()}")

    # ---------- Paso 1 ----------
    cmd1 = [sys.executable, str(scripts_path / script_catalogo),
            "--url", url, "--out_dir", str(out_base)]
    _, rc = run_command(cmd1, scripts_path)
    if rc: st.error("Error en paso 1"); st.stop()

    # ---------- Paso 2 ----------
    cmd2 = [sys.executable, str(scripts_path / script_imagenes),
            "--url", url, "--out_dir", str(out_base), "--headless"]
    _, rc = run_command(cmd2, scripts_path)
    if rc: st.error("Error en paso 2"); st.stop()

    # ---------- Paso 3 ----------
    cmd3 = [sys.executable, str(scripts_path / script_excel),
            "--url", url, "--out_dir", str(out_base)]
    _, rc = run_command(cmd3, scripts_path)
    if rc: st.error("Error en paso 3"); st.stop()

    # ---------- ZIP ----------
    ts = datetime.datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    zip_path = out_base / f"extract_{plataforma}_{current_run_id}_{ts}.zip"
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in run_dir.rglob("*"):
            zf.write(f, f.relative_to(run_dir))

    st.success("¡Proceso completado!")
    st.download_button("Descargar resultados",
                       zip_path.read_bytes(),
                       file_name=zip_path.name,
                       mime="application/zip")

# ─────────────────────────────────────────────────────────
if __name__ == "__main__":
    main()