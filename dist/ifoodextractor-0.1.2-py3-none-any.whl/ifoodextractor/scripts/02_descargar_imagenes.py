#!/usr/bin/env python3
# 02_descargar_imagenes.py  – versión robusta para consolas CP-1252 / UTF-8

import os
import re
import json
import time
import argparse
from pathlib import Path
from urllib.parse import urljoin

import pandas as pd
import requests
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import sys          #  <<<  añadido para reconfigurar stdout

# -------------- NUEVO: detectar entorno Streamlit Cloud --------------
RUNNING_IN_STCLOUD = (
    os.getenv("STREAMLIT_EXECUTION_ENV", "").lower() == "cloud"
    or os.getenv("STREAMLIT_SERVER", "")              # por si cambia el nombre
)
# ---------------------------------------------------------------------

# ----------------------------------------------------------------------
# Si el intérprete lo permite, fuerce UTF-8 en Windows
# ----------------------------------------------------------------------
if os.name == "nt":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except AttributeError:
        # Python < 3.7  (no tiene reconfigure).  No pasa nada: se usará el log() seguro.
        pass

# ----------------------------------------------------------------------
# Constantes y helpers
# ----------------------------------------------------------------------
IFOOD_CDN = "https://static.ifood-static.com.br"


def log(msg: str, logfile: Path) -> None:
    """
    Imprime el mensaje en pantalla y lo guarda en un fichero.
    Si la consola no acepta UTF-8 (p.ej. Windows CP-1252), se vuelve a
    imprimir eliminando los caracteres conflictivos.
    """
    try:
        print(msg)
    except UnicodeEncodeError:
        safe = msg.encode("ascii", errors="ignore").decode("ascii")
        print(safe)

    with logfile.open("a", encoding="utf-8") as f:
        f.write(msg + "\n")


def extract_merchant_id(url: str) -> str | None:
    m = re.search(r"([a-f0-9\-]{36})(?:$|/|\?)", url)
    return m.group(1) if m else None


def fix_ifood_url(u: str | None) -> str | None:
    """
    Convierte rutas parciales en URLs absolutas de la CDN de iFood.
    """
    if not u or not isinstance(u, str):
        return None
    if u.startswith("http"):
        return u
    if u.startswith("//"):
        return "https:" + u
    if u.startswith("/"):
        return urljoin(IFOOD_CDN, u.lstrip("/"))
    return urljoin(IFOOD_CDN + "/", u)


def download_image(img_url: str, local_path: Path, timeout: int = 25) -> bool:
    """Devuelve True si la descarga fue correcta."""
    try:
        r = requests.get(img_url,
                         headers={"User-Agent": "Mozilla/5.0"},  # UA por si la CDN lo exige
                         timeout=timeout)
        r.raise_for_status()
        local_path.write_bytes(r.content)
        return True
    except Exception:
        return False


def safe_filename(txt: str, maxlen: int = 60) -> str:
    return re.sub(r"[^\w\-_\. ]", "_", txt)[:maxlen]


# ----------------------------------------------------------------------
# main
# ----------------------------------------------------------------------
def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--url",     required=False, help="URL de la tienda iFood")
    parser.add_argument("--out_dir", default="salida", help="Carpeta base de salida")
    parser.add_argument("--limit",   type=int, default=0,
                        help="Procesar sólo los primeros N productos (0 = todos)")
    parser.add_argument("--headless", action="store_true", help="Chrome headless")
    parser.add_argument("--skip_selenium", action="store_true",
                        help="No usar Selenium ni siquiera como fallback")
    args = parser.parse_args()

    # -------- NUEVO: si estamos en Streamlit Cloud, fuerza el flag ----
    if RUNNING_IN_STCLOUD:
        args.skip_selenium = True

    # -----------------------------------------------------------------

    url = args.url or input("URL del restaurante iFood: ").strip()
    merchant_id = extract_merchant_id(url)
    if not merchant_id:
        print("merchant_id no encontrado en la URL.")
        return

    OUT_DIR = Path(args.out_dir) / merchant_id
    IMG_DIR = OUT_DIR / "img"
    IMG_DIR.mkdir(parents=True, exist_ok=True)
    logfile = OUT_DIR / "log_02.txt"

    prod_csv = OUT_DIR / "menu_productos_base.csv"
    opt_csv  = OUT_DIR / "menu_opciones_base.csv"
    if not prod_csv.exists():
        print("No existe menu_productos_base.csv. Ejecuta primero 01_extraer_catalogo.py")
        return

    df_prod = pd.read_csv(prod_csv, encoding="utf-8")
    df_opt  = pd.read_csv(opt_csv, encoding="utf-8") if opt_csv.exists() else pd.DataFrame()

    # Limitar para pruebas
    if args.limit > 0:
        df_prod = df_prod.head(args.limit)
        if not df_opt.empty:
            ids_keep = set(df_prod["product_id"])
            df_opt = df_opt[df_opt["product_id"].isin(ids_keep)]

    log(f"Productos a procesar: {len(df_prod)}", logfile)

    # ------------------------------------------------------------------
    # Primer intento: utilizar los URL que ya vienen en el CSV
    # ------------------------------------------------------------------
    product_img_paths: dict[str, str] = {}
    opcion_img_paths:  dict[str, str] = {}

    for _, row in df_prod.iterrows():
        code   = str(row["product_code"])
        nombre = str(row["product_name"])
        img_url = fix_ifood_url(row.get("api_image_url"))
        if not img_url:
            continue
        ext  = os.path.splitext(img_url)[1].split("?")[0] or ".jpg"
        path = IMG_DIR / f"{safe_filename(code+'_'+nombre)}{ext}"
        if download_image(img_url, path):
            product_img_paths[code] = str(path)
        else:
            log(f"[WARN] Falló descarga directa PROD {code}", logfile)

    if not df_opt.empty and "option_image_url" in df_opt.columns:
        for _, row in df_opt.iterrows():
            opc_id   = str(row["option_id"])
            opc_name = str(row.get("option_name", ""))
            img_url  = fix_ifood_url(row.get("option_image_url"))
            if not img_url:
                continue
            ext  = os.path.splitext(img_url)[1].split("?")[0] or ".jpg"
            path = IMG_DIR / f"{safe_filename('OPC_'+opc_id+'_'+opc_name)}{ext}"
            if download_image(img_url, path):
                opcion_img_paths[opc_id] = str(path)
            else:
                log(f"[WARN] Falló descarga directa OPC {opc_id}", logfile)

    # ------------------------------------------------------------------
    # Faltantes -> Selenium (si no se deshabilitó)
    # ------------------------------------------------------------------
    faltan_prod = set(df_prod["product_code"].astype(str)) - set(product_img_paths)
    faltan_opt  = set(df_opt["option_id"].astype(str))     - set(opcion_img_paths)

    if (faltan_prod or faltan_opt) and not args.skip_selenium:
        log("-> Lanzando Selenium para imágenes faltantes…", logfile)

        chrome_opts = webdriver.ChromeOptions()
        if args.headless:
            chrome_opts.add_argument("--headless=new")
            chrome_opts.add_argument("--no-sandbox")
            chrome_opts.add_argument("--disable-gpu")

        driver = webdriver.Chrome(options=chrome_opts)
        driver.get(url)
        time.sleep(8)

        # scroll largo para cargar todo
        for _ in range(10):
            driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            time.sleep(1.2)

        cards = driver.find_elements(By.CSS_SELECTOR,
                 'li[data-test-id="restaurant-menu-group-item"]')

        for card in cards:
            try:
                name = card.find_element(By.CSS_SELECTOR,
                                         '.dish-card__info').text.split('\n')[0].strip()
                driver.execute_script(
                    "arguments[0].scrollIntoView({block:'center'});", card)
                WebDriverWait(driver, 5).until(
                    EC.presence_of_element_located((By.CSS_SELECTOR,
                        'div.dish-card__container-image img')))

                img_url = fix_ifood_url(
                    card.find_element(By.CSS_SELECTOR,
                        'div.dish-card__container-image img').get_attribute("src"))

                if not img_url:
                    continue

                # Producto principal
                prod_match = df_prod[df_prod["product_name"] == name]
                if not prod_match.empty:
                    code = str(prod_match.iloc[0]["product_code"])
                    if code in faltan_prod:
                        ext  = os.path.splitext(img_url)[1].split("?")[0] or ".jpg"
                        path = IMG_DIR / f"{safe_filename(code+'_'+name)}{ext}"
                        if download_image(img_url, path):
                            product_img_paths[code] = str(path)
                            faltan_prod.discard(code)
                            log(f"Descargada Selenium PROD {code}", logfile)
                # No intentamos toppings por Selenium (rara vez aparecen)

            except Exception as e:
                log(f"[ERR] Selenium loop: {e}", logfile)

        driver.quit()

    # ------------------------------------------------------------------
    # Guardar mapeos y finalizar
    # ------------------------------------------------------------------
    (OUT_DIR / "paths_img.json").write_text(
        json.dumps(product_img_paths, ensure_ascii=False, indent=2), encoding="utf-8")

    (OUT_DIR / "paths_img_opciones.json").write_text(
        json.dumps(opcion_img_paths, ensure_ascii=False, indent=2), encoding="utf-8")

    log(f"Imágenes productos  : {len(product_img_paths)}", logfile)
    log(f"Imágenes opciones   : {len(opcion_img_paths)}", logfile)
    log("Script 02_descargar_imagenes finalizado.\n", logfile)


if __name__ == "__main__":
    main()
