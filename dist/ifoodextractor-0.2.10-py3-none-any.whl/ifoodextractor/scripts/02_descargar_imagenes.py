#!/usr/bin/env python3
# 02_descargar_imagenes.py  – descarga directa + Playwright fallback

import os, re, json, argparse, subprocess, sys, time
from pathlib import Path
from urllib.parse import urljoin

import pandas as pd
import requests
from playwright.sync_api import sync_playwright, Error

IFOOD_CDN = "https://static.ifood-static.com.br"

# ───────────────────────── helpers ────────────────────────────────
def log(msg: str, logfile: Path) -> None:
    try:  print(msg)
    except UnicodeEncodeError:
        print(msg.encode("ascii","ignore").decode())
    logfile.write_text(logfile.read_text("utf-8", errors="ignore")+msg+"\n",
                       encoding="utf-8", errors="ignore")

def fix_ifood_url(u: str | None) -> str | None:
    if not u or not isinstance(u, str):   return None
    if u.startswith("http"): return u
    if u.startswith("//"):   return "https:"+u
    if u.startswith("/"):    return urljoin(IFOOD_CDN, u.lstrip("/"))
    return urljoin(IFOOD_CDN+"/", u)

def download_image(url: str, dst: Path, timeout=25) -> bool:
    try:
        r = requests.get(url, headers={"User-Agent":"Mozilla/5.0"}, timeout=timeout)
        r.raise_for_status()
        dst.write_bytes(r.content)
        return True
    except Exception:
        return False

def safe_filename(txt, maxlen=60):
    return re.sub(r"[^\w\-. ]","_",txt)[:maxlen]

def extract_merchant_id(url:str) -> str|None:
    m = re.search(r"([a-f0-9\-]{36})(?:$|/|\?)", url)
    return m.group(1) if m else None
# ──────────────────────────────────────────────────────────────────


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", required=False)
    ap.add_argument("--out_dir", default="salida")
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--headless", action="store_true")
    args = ap.parse_args()

    url = args.url or input("URL iFood: ").strip()
    mid = extract_merchant_id(url)
    if not mid:
        print("merchant_id no encontrado."); return

    OUT = Path(args.out_dir)/mid
    IMG = OUT/"img";  IMG.mkdir(parents=True, exist_ok=True)
    logf= OUT/"log_02.txt"; logf.touch(exist_ok=True)

    df_prod = pd.read_csv(OUT/"menu_productos_base.csv", encoding="utf-8")
    if args.limit>0: df_prod = df_prod.head(args.limit)

    log(f"Productos a procesar: {len(df_prod)}", logf)

    product_img_paths: dict[str,str] = {}

    # ───────── 1) Descarga directa desde la API ──────────
    for _,row in df_prod.iterrows():
        code = str(row["product_code"])
        name = str(row["product_name"])
        img_url = fix_ifood_url(row.get("api_image_url"))
        if not img_url: continue
        ext = os.path.splitext(img_url)[1].split("?")[0] or ".jpg"
        dst = IMG / f"{safe_filename(code+'_'+name)}{ext}"
        if download_image(img_url, dst):
            product_img_paths[code] = str(dst)
        else:
            log(f"[WARN] directa KO {code}", logf)

    # ids aún sin imagen
    faltan = set(df_prod["product_code"].astype(str)) - set(product_img_paths)

    # ───────── 2) Playwright fallback ────────────────────
    if faltan:
        log("-> Playwright para imágenes faltantes…", logf)
        with sync_playwright() as pw:
            try:
                browser = pw.chromium.launch(headless=args.headless)
            except Error as e:
                if "Executable doesn't exist" in str(e):
                    log("Descargando Chromium…", logf)
                    subprocess.check_call([sys.executable,"-m","playwright",
                                           "install","chromium"])
                    browser = pw.chromium.launch(headless=args.headless)
                else:
                    raise
            page = browser.new_page()
            page.goto(url, timeout=60_000)
            page.wait_for_timeout(8_000)

            cards = page.query_selector_all(
                'li[data-test-id="restaurant-menu-group-item"]')
            log(f"Tarjetas detectadas: {len(cards)}", logf)

            code2name = dict(zip(df_prod["product_code"].astype(str),
                                 df_prod["product_name"]))

            for card in cards:
                try:
                    # llevarla al centro ⇒ dispara lazy-load
                    card.scroll_into_view_if_needed(timeout=5_000)
                    page.wait_for_timeout(300)  # pequeño delay

                    name_node = card.query_selector('.dish-card__info')
                    if not name_node: continue
                    name = name_node.inner_text().split('\n')[0].strip()

                    img_node = card.query_selector(
                        'div.dish-card__container-image img')
                    if not img_node: continue
                    img_url = fix_ifood_url(img_node.get_attribute("src"))
                    if not img_url: continue

                    # búsqueda por nombre -> obtiene código
                    try:
                        code = next(c for c,n in code2name.items() if n==name)
                    except StopIteration:
                        continue
                    if code not in faltan:
                        continue

                    ext = os.path.splitext(img_url)[1].split("?")[0] or ".jpg"
                    dst = IMG / f"{safe_filename(code+'_'+name)}{ext}"
                    if download_image(img_url, dst):
                        product_img_paths[code] = str(dst)
                        faltan.discard(code)
                        log(f"Playwright OK {code}", logf)
                except Exception as e:
                    log(f"[ERR] tarjeta: {e}", logf)

            browser.close()

    # ──────── guardar mapeo y terminar ─────────
    (OUT/"paths_img.json").write_text(
        json.dumps(product_img_paths, ensure_ascii=False, indent=2),
        encoding="utf-8")

    log(f"Imágenes descargadas: {len(product_img_paths)} "
        f" | faltantes: {len(faltan)}", logf)
    log("Script 02_descargar_imagenes finalizado.\n", logf)


if __name__ == "__main__":
    main()