#!/usr/bin/env python3
# 01_extraer_catalogo_rappi.py

import json
import re
import argparse
import requests
from pathlib import Path
from urllib.parse import urlparse

def log(msg: str, logfile: Path) -> None:
    print(msg)
    logfile.write_text((logfile.read_text("utf-8") if logfile.exists() else "")
                       + msg + "\n", encoding="utf-8")

def extract_rappi_store_id(url: str) -> str | None:
    # Ej: https://www.rappi.com.br/restaurantes/900663315-joakins-hamburguers
    match = re.search(r'/restaurantes/([\d]+)-', url)
    if match:
        return match.group(1)
    # Alternativa general:
    match = re.search(r'/restaurantes/(\d+)', url)
    if match:
        return match.group(1)
    return None

def obtener_slug(full_url: str) -> str:
    segs = [s for s in urlparse(full_url).path.split("/") if s]
    return segs[-1] if len(segs) >= 2 else "desconocido"

def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--url", required=True)
    p.add_argument("--token", required=True)
    p.add_argument("--lat", type=float, default=-23.55052)   # Puedes cambiar las coords por las reales
    p.add_argument("--lon", type=float, default=-46.633309)
    p.add_argument("--out_dir", default="salida")
    p.add_argument("--deviceid", default="a00695b2-9651-4977-8141-63bb0001ecc0R")
    args = p.parse_args()

    OUT_BASE = Path(args.out_dir).expanduser().resolve()
    url = args.url
    store_id = extract_rappi_store_id(url)
    if not store_id:
        print("No se pudo extraer store_id de la URL")
        exit(1)
    OUT_DIR = OUT_BASE / store_id
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    logfile = OUT_DIR / "log_01.txt"

    lat, lon = args.lat, args.lon

    # === Rappi API ===
    api_url = f"https://services.rappi.com.br/api/web-gateway/web/restaurants-bus/store/id/{store_id}/"
    headers = {
        "accept": "application/json",
        "accept-language": "pt-BR",
        "app-version": "1.157.1",
        "app-version-name": "1.157.1",
        "authorization": f"Bearer {args.token}",
        "content-type": "application/json; charset=UTF-8",
        "deviceid": args.deviceid,
        "origin": "https://www.rappi.com.br",
        "referer": "https://www.rappi.com.br/",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36",
    }
    payload = {
        "lat": lat,
        "lng": lon,
        "store_type": "restaurant",
        "is_prime": False,
        "prime_config": {
            "unlimited_shipping": False
        }
    }
    log(f"Llamando a la API de Rappi...", logfile)
    resp = requests.post(api_url, headers=headers, json=payload, timeout=30)
    if not resp.ok:
        log(f"Error en Rappi API: {resp.text}", logfile)
        exit(2)

    catalog = resp.json()
    (OUT_DIR / "catalog_raw.json").write_text(
        json.dumps(catalog, ensure_ascii=False, indent=2), encoding="utf-8")

    with (OUT_DIR / "info_negocio.txt").open("w", encoding="utf-8") as f:
        f.write(f"restaurant_slug: {obtener_slug(url)}\n")
        f.write(f"store_id:        {store_id}\n")
        f.write(f"latitude:        {lat}\nlongitude:       {lon}\nurl: {url}\n")

    # === PROCESAR PRODUCTOS Y OPCIONES ===

    from pandas import DataFrame

    rows_prod, rows_opt = [], []
    try:
        categorias = catalog["store"]["menu"]["categories"]
    except Exception as e:
        log(f"Error al parsear categorías: {e}", logfile)
        exit(3)

    for cat in categorias:
        cat_id = cat.get("id")
        cat_name = cat.get("name")
        for item in cat.get("items", []):
            prod_id = item.get("id")
            prod_code = prod_id  # Rappi no maneja code como tal
            prod_desc = item.get("name")
            details = item.get("description")
            price = item.get("price")
            img_url = (
                item.get("image", {}).get("url") or
                item.get("image", {}).get("default") or
                None
            )
            rows_prod.append({
                "category_id": cat_id,
                "category": cat_name,
                "product_id": prod_id,
                "product_code": prod_code,
                "product_name": prod_desc,
                "details": details,
                "price": price,
                "api_image_url": img_url
            })

            # OPCIONES (modifiers)
            for group in item.get("groupModifiers", []):
                grp_name = group.get("name")
                for opc in group.get("options", []):
                    op_id = opc.get("id")
                    op_code = op_id
                    op_name = opc.get("name")
                    op_price = opc.get("price")
                    opc_img_url = (
                        opc.get("image", {}).get("url") or
                        opc.get("image", {}).get("default") or
                        None
                    )
                    rows_opt.append({
                        "product_id": prod_id,
                        "product_name": prod_desc,
                        "group": grp_name,
                        "option_id": op_id,
                        "option_code": op_code,
                        "option_name": op_name,
                        "option_price": op_price,
                        "option_image_url": opc_img_url
                    })

    DataFrame(rows_prod).to_csv(OUT_DIR / "menu_productos_base.csv", index=False)
    if rows_opt:
        DataFrame(rows_opt).to_csv(OUT_DIR / "menu_opciones_base.csv", index=False)
    log("01_extraer_catalogo_rappi completado", logfile)

if __name__ == "__main__":
    main()