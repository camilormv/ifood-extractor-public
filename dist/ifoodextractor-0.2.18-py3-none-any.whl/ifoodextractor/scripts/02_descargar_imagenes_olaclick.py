#!/usr/bin/env python3
# 02_descargar_imagenes_olaclick.py – Descarga directa de imágenes OlaClick
# v1.1 – ahora acepta (e ignora) el flag --headless para compatibilidad

import os, re, json, argparse
from pathlib import Path
from typing import Dict

import pandas as pd
import requests

# ───────── utilidades ──────────
def log(msg: str, logfile: Path) -> None:
    """Imprime y añade al log."""
    try:
        print(msg)
    except UnicodeEncodeError:
        print(msg.encode("ascii", "ignore").decode())
    logfile.write_text(
        logfile.read_text("utf-8", errors="ignore") + msg + "\n",
        encoding="utf-8",
        errors="ignore",
    )

def safe_filename(txt: str, maxlen: int = 60) -> str:
    return re.sub(r"[^\w\-. ]", "_", txt)[:maxlen]

def extract_olaclick_company_slug(url: str) -> str | None:
    m = re.search(r"//([a-z0-9\-]+)\.ola\.click", url)
    return m.group(1) if m else None

def download_image(url: str, dst: Path, timeout: int = 25) -> bool:
    try:
        r = requests.get(url,
                         headers={"User-Agent": "Mozilla/5.0"},
                         timeout=timeout)
        r.raise_for_status()
        dst.write_bytes(r.content)
        return True
    except Exception:
        return False

# ───────── main ──────────
def main() -> None:
    parser = argparse.ArgumentParser(
        description="Descarga las imágenes de producto/opciones para OlaClick"
    )
    parser.add_argument("--url")
    parser.add_argument("--out_dir", default="salida")
    parser.add_argument("--limit", type=int, default=0)
    # compatibilidad: aceptamos --headless pero no lo usamos
    parser.add_argument("--headless", action="store_true",
                        help="(ignorada, sólo para compatibilidad)")
    args = parser.parse_args()

    url = args.url or input("URL OlaClick: ").strip()
    slug = extract_olaclick_company_slug(url)
    if not slug:
        print("No se pudo extraer identificador de OlaClick.")
        return

    OUT = Path(args.out_dir) / slug
    IMG = OUT / "img"
    IMG.mkdir(parents=True, exist_ok=True)
    logf = OUT / "log_02.txt"
    logf.touch(exist_ok=True)

    prod_csv_path = OUT / "menu_productos_base.csv"
    if not prod_csv_path.exists():
        log(f"[ERROR] No existe el catálogo de productos en {prod_csv_path}", logf)
        return

    df_prod = pd.read_csv(prod_csv_path, encoding="utf-8")
    if args.limit > 0:
        df_prod = df_prod.head(args.limit)

    log(f"Productos a procesar: {len(df_prod)}", logf)
    product_img_paths: Dict[str, str] = {}

    # ───── 1) productos ─────
    for _, row in df_prod.iterrows():
        code    = str(row.get("product_code", ""))
        name    = str(row.get("product_name", ""))
        img_url = row.get("api_image_url") or row.get("product_image_url")
        if not (isinstance(img_url, str) and img_url.startswith("http")):
            continue
        ext = os.path.splitext(img_url)[1].split("?")[0] or ".jpg"
        dst = IMG / f"{safe_filename(code + '_' + name)}{ext}"
        if download_image(img_url, dst):
            product_img_paths[code] = str(dst)
        else:
            log(f"[WARN] fallo descarga: {code} {img_url}", logf)

    # ───── 2) opciones (toppings/extras) ─────
    opciones_csv_path  = OUT / "menu_opciones_base.csv"
    opc_img_json_path  = OUT / "paths_img_opciones.json"
    option_img_paths: Dict[str, str] = {}

    if opciones_csv_path.exists():
        df_opt = pd.read_csv(opciones_csv_path, encoding="utf-8")
        for _, row in df_opt.iterrows():
            code    = str(row.get("option_id", ""))
            name    = str(row.get("option_name", ""))
            img_url = row.get("option_image_url")
            if not (isinstance(img_url, str) and img_url.startswith("http")):
                continue
            ext = os.path.splitext(img_url)[1].split("?")[0] or ".jpg"
            dst = IMG / f"opc_{safe_filename(code + '_' + name)}{ext}"
            if download_image(img_url, dst):
                option_img_paths[code] = str(dst)
            else:
                log(f"[WARN] fallo descarga opc: {code} {img_url}", logf)

        if option_img_paths:
            opc_img_json_path.write_text(
                json.dumps(option_img_paths, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )

    # ───── guardar mapeos ─────
    (OUT / "paths_img.json").write_text(
        json.dumps(product_img_paths, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    log(
        f"Imágenes descargadas: {len(product_img_paths)} productos | "
        f"{len(option_img_paths)} opciones",
        logf,
    )
    log("Script 02_descargar_imagenes_olaclick finalizado.\n", logf)


if __name__ == "__main__":
    main()