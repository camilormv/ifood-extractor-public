#!/usr/bin/env python3
# 03_unir_imagenes_excel.py – FIX rutas absolutas

import pandas as pd, json, argparse, re, sys
from pathlib import Path

def log(msg: str, logfile: Path) -> None:
    try:
        print(msg)
    except UnicodeEncodeError:
        print(msg.encode("ascii", "ignore").decode("ascii"))
    logfile.write_text((logfile.read_text("utf-8") if logfile.exists() else "")
                       + msg + "\n", encoding="utf-8")

def extract_merchant_id(url: str) -> str | None:
    m = re.search(r"([a-f0-9\-]{36})(?:$|/|\?)", url)
    return m.group(1) if m else None

def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--url", required=True)
    p.add_argument("--out_dir", default="salida")
    args = p.parse_args()

    # ───── FIX directorio absoluto ─────
    OUT_BASE = Path(args.out_dir).expanduser().resolve()
    # ───────────────────────────────────

    merchant_id = extract_merchant_id(args.url)
    if not merchant_id:
        print("merchant_id no encontrado.")
        sys.exit(1)

    OUT_DIR = OUT_BASE / merchant_id
    logfile = OUT_DIR / "log_03.txt"

    # … resto del script sin cambios …