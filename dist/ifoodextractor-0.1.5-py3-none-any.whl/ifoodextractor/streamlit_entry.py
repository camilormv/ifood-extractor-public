#!/usr/bin/env python3
# streamlit_entry.py  – interfaz Streamlit (Playwright)

import subprocess, sys, datetime, zipfile, os
from pathlib import Path
from typing import List, Tuple

import streamlit as st
import importlib.resources as pkg_resources

# ------------------- Ajustes UI --------------------
st.set_page_config(page_title="Extractor de menús iFood",
                   layout="centered")

st.title("🍽️  Extractor de menús iFood")

# -------------- helper -----------------------------
def run_command(cmd: List[str], cwd: Path) -> Tuple[str, int]:
    placeholder = st.empty()
    lines: List[str] = []
    proc = subprocess.Popen(cmd, cwd=cwd,
                            stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, text=True)
    assert proc.stdout
    for line in proc.stdout:
        lines.append(line.rstrip())
        placeholder.code("\n".join(lines[-300:]))
    proc.wait()
    return "\n".join(lines), proc.returncode
# ---------------------------------------------------

def main() -> None:
    url      = st.text_input("URL del restaurante iFood")
    out_dir  = st.text_input("Carpeta base de salida:", value="salida")

    if not st.button("Iniciar proceso"):
        return
    if not url.strip():
        st.warning("Debes introducir una URL válida."); st.stop()

    # -------- carpetas ----------
    out_base = Path(out_dir).expanduser()
    out_base.mkdir(parents=True, exist_ok=True)

    from ifoodextractor import scripts
    scripts_path = Path(pkg_resources.files(scripts))
    st.info(f"Scripts en: {scripts_path}")

    # 1. catálogo
    st.markdown("### 1️⃣  Extrayendo catálogo …")
    _, rc = run_command([sys.executable,
                         str(scripts_path / "01_extraer_catalogo.py"),
                         "--url", url, "--out_dir", str(out_base)],
                        scripts_path)
    if rc: st.error("Fallo en paso 1"); st.stop()

    # 2. imágenes (Playwright)
    st.markdown("### 2️⃣  Descargando imágenes …")
    _, rc = run_command([sys.executable,
                         str(scripts_path / "02_descargar_imagenes.py"),
                         "--url", url, "--out_dir", str(out_base),
                         "--headless"],
                        scripts_path)
    if rc: st.error("Fallo en paso 2"); st.stop()

    # 3. Excel
    st.markdown("### 3️⃣  Generando Excel …")
    _, rc = run_command([sys.executable,
                         str(scripts_path / "03_unir_imagenes_excel.py"),
                         "--url", url, "--out_dir", str(out_base)],
                        scripts_path)
    if rc: st.error("Fallo en paso 3"); st.stop()

    # ZIP
    st.markdown("### 📦  Empaquetando …")
    ts  = datetime.datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    zip_path = out_base / f"ifood_extract_{ts}.zip"
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in out_base.rglob("*"):
            if f == zip_path: continue
            zf.write(f, f.relative_to(out_base))
    st.success("¡Proceso completado!")
    st.download_button("Descargar resultados", zip_path.read_bytes(),
                       file_name=zip_path.name, mime="application/zip")

if __name__ == "__main__":
    main()