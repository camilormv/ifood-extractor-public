#!/usr/bin/env python3
# streamlit_entry.py  – interfaz Streamlit (Playwright)

import subprocess, sys, datetime, zipfile, os
from pathlib import Path
from typing import List, Tuple

import streamlit as st
import importlib.resources as pkg_resources


# ------------------- Ajustes UI --------------------
st.set_page_config(page_title="Extractor de menús iFood",
                   layout="centered")

st.title("🍽️  Extractor de menús iFood")

# -------------- helper -----------------------------
def run_command(cmd: List[str], cwd: Path) -> Tuple[str, int]:
    placeholder = st.empty()
    lines: List[str] = []
    proc = subprocess.Popen(cmd, cwd=cwd,
                            stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, text=True)
    assert proc.stdout
    for line in proc.stdout:
        lines.append(line.rstrip())
        placeholder.code("\n".join(lines[-300:]))
    proc.wait()
    return "\n".join(lines), proc.returncode
# ---------------------------------------------------

def main() -> None:
    url = st.text_input("URL del restaurante iFood")

    #  ⬇  Caja donde el usuario escribe SOLO el nombre de la carpeta
    carpeta_out = st.text_input(
        "Carpeta base de salida (se creará dentro del workspace de Streamlit):",
        value="salida"
    )

    if not st.button("Iniciar proceso"):
        return
    if not url.strip():
        st.warning("Debes introducir una URL."); st.stop()

    # ─────────────────────────────────────────────────────────────
    #  RUTA DE SALIDA (solo se permite dentro del workspace)
    # ─────────────────────────────────────────────────────────────
    workspace_root = Path.cwd()          # raíz del contenedor Streamlit
    # eliminamos posibles sub-rutas o caracteres conflictivos
    safe_name = Path(carpeta_out).name or "salida"
    out_base  = (workspace_root / safe_name).resolve()
    out_base.mkdir(parents=True, exist_ok=True)
    # ─────────────────────────────────────────────────────────────

    # ubicación de los scripts empaquetados
    from ifoodextractor import scripts
    scripts_path = Path(pkg_resources.files(scripts))
    st.info(f"Guardando resultados en: {out_base.as_posix()}")

    # ---------- Paso 1 (catálogo) ----------
    cmd1 = [sys.executable, str(scripts_path / "01_extraer_catalogo.py"),
            "--url", url, "--out_dir", str(out_base)]
    _, rc = run_command(cmd1, scripts_path)
    if rc: st.error("Error en paso 1"); st.stop()

    # ---------- Paso 2 (imágenes – Playwright) ----------
    cmd2 = [sys.executable, str(scripts_path / "02_descargar_imagenes.py"),
            "--url", url, "--out_dir", str(out_base), "--headless"]
    _, rc = run_command(cmd2, scripts_path)
    if rc: st.error("Error en paso 2"); st.stop()

    # ---------- Paso 3 (Excel) ----------
    cmd3 = [sys.executable, str(scripts_path / "03_unir_imagenes_excel.py"),
            "--url", url, "--out_dir", str(out_base)]
    _, rc = run_command(cmd3, scripts_path)
    if rc: st.error("Error en paso 3"); st.stop()

    # ---------- ZIP ----------
    ts = datetime.datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    zip_path = out_base / f"ifood_extract_{ts}.zip"
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in out_base.rglob("*"):
            if f == zip_path: continue
            zf.write(f, f.relative_to(out_base))
    st.success("¡Proceso completado!")
    st.download_button("Descargar resultados", zip_path.read_bytes(),
                       file_name=zip_path.name, mime="application/zip")

if __name__ == "__main__":
    main()