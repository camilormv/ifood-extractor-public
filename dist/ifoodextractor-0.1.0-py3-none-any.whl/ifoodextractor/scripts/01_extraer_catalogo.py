#!/usr/bin/env python3
# 01_extraer_catalogo.py   – versión corregida (jun-2024)

import json
import requests
import pandas as pd
from pathlib import Path
import re
import argparse
from urllib.parse import urlparse, unquote

from util_coords import descargar_html, extraer_coordenadas


# ───────────────────────── helpers ──────────────────────────────────
def log(msg: str, logfile: Path) -> None:
    with logfile.open("a", encoding="utf-8") as f:
        print(msg)
        f.write(msg + "\n")


def extract_merchant_id(url: str) -> str | None:
    m = re.search(r"([a-f0-9\-]{36})(?:$|/|\?)", url)
    return m.group(1) if m else None


def obtener_nombre_desde_url(full_url: str) -> str:
    """
    Devuelve el penúltimo segmento de la URL, que iFood usa como slug
    del restaurante.
    Ej.:  .../mita---liberdade-i-liberdade/b5f29f47-...  →  mita---liberdade-i-liberdade
    """
    path = unquote(urlparse(full_url).path)           # /delivery/uf/cidade/slug/merchant_id
    segmentos = [s for s in path.split("/") if s]     # elimina cadenas vacías
    return segmentos[-2] if len(segmentos) >= 2 else "desconocido"


def primera_no_vacia(*valores):
    """
    Devuelve el primer argumento que no sea None ni cadena vacía.
    """
    for v in valores:
        if v:
            return v
    return None
# ────────────────────────────────────────────────────────────────────


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--url",     type=str, help="URL de la tienda en iFood")
    parser.add_argument("--out_dir", type=str, default="salida",
                        help="Carpeta base donde se guardarán los archivos")
    args = parser.parse_args()

    url = args.url or input("Pega la URL de la tienda ifood: ").strip()
    merchant_id = extract_merchant_id(url)
    if not merchant_id:
        print("[ERROR] No pude extraer merchant_id de la URL. Revisa la url.")
        return

    OUT_DIR = Path(args.out_dir) / merchant_id
    OUT_DIR.mkdir(exist_ok=True, parents=True)
    logfile = OUT_DIR / "log_01.txt"

    # ------------------ Coordenadas -----------------------------------
    try:
        html = descargar_html(url)
        lat, lon = extraer_coordenadas(html)
    except Exception as e:
        log(f"[ERROR] No se pudieron detectar las coordenadas: {e}", logfile)
        return

    log(f"Latitud: {lat}  Longitud: {lon}", logfile)

    # ------------------ Descarga de catálogo --------------------------
    headers = {
        "accept":                "application/json, text/plain, */*",
        "user-agent":            "Mozilla/5.0",
        "x-client-application-key": "41a266ee-51b7-4c37-9e9d-5cd331f280d5",
        "x-ifood-device-id":     "69d8742f-f8cc-4c85-a24a-d5c0fdd8ea1f",
        "x-ifood-session-id":    "a76ed1e4-5406-4e3e-96a6-869551577cf5",
        "referer":               "https://www.ifood.com.br/"
    }

    catalog_url = f"https://marketplace.ifood.com.br/v1/merchants/{merchant_id}/catalog"
    params = {"latitude": lat, "longitude": lon}

    log(f"Descargando catálogo de {merchant_id} …", logfile)
    try:
        resp = requests.get(catalog_url, params=params, headers=headers, timeout=30)
        resp.raise_for_status()
        catalog = resp.json()
        (OUT_DIR / "catalog_raw.json").write_text(
            json.dumps(catalog, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception as e:
        log(f"[ERROR] Fallo descargando catálogo: {e}", logfile)
        return

    # ------------------ info_negocio.txt ------------------------------
    restaurant_name = obtener_nombre_desde_url(url)
    with (OUT_DIR / "info_negocio.txt").open("w", encoding="utf-8") as fmeta:
        fmeta.write(f"restaurant_name: {restaurant_name}\n")
        fmeta.write(f"merchant_id:    {merchant_id}\n")
        fmeta.write(f"latitude:       {lat}\n")
        fmeta.write(f"longitude:      {lon}\n")
        fmeta.write(f"url:            {url}\n")

    # ------------------ Procesar catálogo -----------------------------
    rows_prod, rows_opt = [], []
    menu_list = catalog["data"]["menu"]

    for cat in menu_list:                          # categorías
        cat_code = cat["code"]
        cat_name = cat["name"]
        for item in cat["itens"]:                  # productos
            img_url = primera_no_vacia(
                item.get("logoUrl"),
                item.get("imageUrl"),
                item.get("photoUrl"),
                item.get("imagePath"),
                (item.get("images", [{}])[0].get("path")
                 if isinstance(item.get("images"), list) and item["images"] else None)
            )

            rows_prod.append({
                "category_code": cat_code,
                "category":      cat_name,
                "product_id":    item["id"],
                "product_code":  item["code"],
                "product_name":  item["description"],
                "details":       item.get("details"),
                "need_choices":  item.get("needChoices"),
                "price":         item.get("unitPrice"),
                "api_image_url": img_url
            })

            # ---------------- Opciones / toppings ---------------------
            for ch in item.get("choices", []):
                group_name = ch.get("name", "")
                for op in ch.get("garnishItens", []):
                    img_url_opc = primera_no_vacia(
                        op.get("logoUrl"),
                        op.get("imageUrl"),
                        op.get("photoUrl"),
                        op.get("imagePath"),
                        (op.get("images", [{}])[0].get("path")
                         if isinstance(op.get("images"), list) and op["images"] else None)
                    )

                    rows_opt.append({
                        "product_id":    item["id"],
                        "product_name":  item["description"],
                        "group":         group_name,
                        "option_id":     op.get("id"),
                        "option_code":   op.get("code", ""),
                        "option_name":   op.get("description"),
                        "option_price":  op.get("unitPrice"),
                        "option_image_url": img_url_opc
                    })

    # -------------- CSV de salida -------------------------------------
    pd.DataFrame(rows_prod).to_csv(OUT_DIR / "menu_productos_base.csv",
                                   index=False, encoding="utf-8")
    log(f"menu_productos_base.csv filas: {len(rows_prod)}", logfile)

    if rows_opt:
        pd.DataFrame(rows_opt).to_csv(OUT_DIR / "menu_opciones_base.csv",
                                      index=False, encoding="utf-8")
        log(f"menu_opciones_base.csv filas: {len(rows_opt)}", logfile)

    log("Script 01_extraer_catalogo finalizado exitosamente.\n", logfile)


if __name__ == "__main__":
    main()