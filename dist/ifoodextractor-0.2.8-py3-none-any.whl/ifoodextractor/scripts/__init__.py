"""
Sub-paquete que contiene los scripts de línea de comandos
(util_coords, 01_extraer_catalogo, 02_descargar_imagenes, 03_unir_imagenes_excel).

No se exporta ninguna API pública: el mero hecho de existir permite
`from ifoodextractor import scripts` en streamlit_entry.py.
"""