#!/usr/bin/env python3
# streamlit_entry.py  – lógica principal de la aplicación

import subprocess
import sys
import datetime
import zipfile
from pathlib import Path
from typing import List, Tuple

import streamlit as st
import importlib.resources as pkg_resources

# ────────────────────────────── Ajustes UI ─────────────────────────────
st.set_page_config(
    page_title="Extractor de menús iFood",
    layout="centered",
    initial_sidebar_state="auto",
)

st.title("🍽️  Extractor de menús iFood")

# ────────────────────────────── Inputs ────────────────────────────────
url: str = st.text_input("URL del restaurante iFood")
out_dir: str = st.text_input(
    "Carpeta base de salida (se creará dentro del workspace):",
    value="salida",
)

run_selenium: bool = st.checkbox(
    "Usar Selenium como último recurso para imágenes",
    value=False,
    help="En Streamlit Cloud no hay Chrome; esta opción solo sirve cuando "
         "la app se ejecuta localmente.",
)

# ──────────────────────── Helper para ejecutar ────────────────────────
def run_command(cmd: List[str], working_dir: Path) -> Tuple[str, int]:
    """
    Ejecuta `cmd` y muestra la salida en tiempo real en la interfaz.
    Devuelve (salida_completa, returncode).
    """
    placeholder = st.empty()
    lines: List[str] = []

    proc = subprocess.Popen(
        cmd,
        cwd=working_dir,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )

    assert proc.stdout is not None  # por mypy
    for line in proc.stdout:
        lines.append(line.rstrip())
        # Mostramos solo las últimas 300 líneas para no saturar el navegador
        placeholder.code("\n".join(lines[-300:]))

    proc.wait()
    return "\n".join(lines), proc.returncode


# ───────────────────────────── Main UI ────────────────────────────────
def main() -> None:
    if not st.button("Iniciar proceso"):
        return

    if not url.strip():
        st.warning("Debes introducir una URL válida.")
        st.stop()

    # Carpeta de salida
    out_base = Path(out_dir).expanduser()
    out_base.mkdir(parents=True, exist_ok=True)

    # Localizar la carpeta where viven los scripts dentro del paquete
    from ifoodextractor import scripts  # sub-paquete con los .py
    scripts_path = Path(pkg_resources.files(scripts))

    st.info(f"Scripts localizados en: {scripts_path.as_posix()}")

    # ---------------------------------- Paso 1 ------------------------
    st.markdown("### 1️⃣  Extrayendo catálogo …")
    cmd1 = [
        sys.executable,
        str(scripts_path / "01_extraer_catalogo.py"),
        "--url", url,
        "--out_dir", str(out_base),
    ]
    _, rc = run_command(cmd1, scripts_path)
    if rc != 0:
        st.error("Fallo en 01_extraer_catalogo.py")
        st.stop()

    # ---------------------------------- Paso 2 ------------------------
    st.markdown("### 2️⃣  Descargando imágenes …")
    cmd2 = [
        sys.executable,
        str(scripts_path / "02_descargar_imagenes.py"),
        "--url", url,
        "--out_dir", str(out_base),
        "--headless",          # por si el usuario corre local con Chrome
    ]
    if not run_selenium:
        cmd2.append("--skip_selenium")
    _, rc = run_command(cmd2, scripts_path)
    if rc != 0:
        st.error("Fallo en 02_descargar_imagenes.py")
        st.stop()

    # ---------------------------------- Paso 3 ------------------------
    st.markdown("### 3️⃣  Generando Excel final …")
    cmd3 = [
        sys.executable,
        str(scripts_path / "03_unir_imagenes_excel.py"),
        "--url", url,
        "--out_dir", str(out_base),
    ]
    _, rc = run_command(cmd3, scripts_path)
    if rc != 0:
        st.error("Fallo en 03_unir_imagenes_excel.py")
        st.stop()

    # ---------------------------------- ZIP ---------------------------
    st.markdown("### 📦  Empaquetando resultados …")
    timestamp = datetime.datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    zip_name = f"ifood_extract_{timestamp}.zip"
    zip_path = out_base / zip_name

    # Cada ejecución crea /salida/<merchant_id>/…
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for file in out_base.rglob("*"):
            if file == zip_path:
                continue
            zf.write(file, file.relative_to(out_base))

    st.success("Proceso completado con éxito 🎉")
    st.download_button(
        label="Descargar resultados (.zip)",
        data=zip_path.read_bytes(),
        file_name=zip_name,
        mime="application/zip",
    )


# ────────────────────────── Entry-point CLI ──────────────────────────
if __name__ == "__main__":
    main()