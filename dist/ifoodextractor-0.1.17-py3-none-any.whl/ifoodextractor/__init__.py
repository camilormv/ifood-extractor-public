"""
iFood Extractor
===============

Paquete que reúne los scripts necesarios para:

* Descargar el catálogo JSON de un restaurante iFood.
* Bajar las imágenes de productos/opciones.
* Generar los Excel finales enlazando imágenes locales.
* Ejecutar una interfaz Streamlit (ver `streamlit_entry.py`).

La lógica pesada vive dentro de `ifoodextractor.scripts`.
"""

__all__ = ["streamlit_entry"]
__version__ = "0.1.4"