#!/usr/bin/env python3
from __future__ import annotations
import re, sys, requests
from typing import Tuple

USER_AGENT = "Mozilla/5.0"
TIMEOUT = 30
RG_LAT = r'"latitude"\s*:\s*([-]?\d+\.\d+)'
RG_LON = r'"longitude"\s*:\s*([-]?\d+\.\d+)'

def descargar_html(url: str) -> str:
    r = requests.get(url, headers={"User-Agent": USER_AGENT}, timeout=TIMEOUT)
    r.raise_for_status()
    return r.text

def extraer_coordenadas(html: str) -> Tuple[float, float]:
    lat = re.search(RG_LAT, html)
    lon = re.search(RG_LON, html)
    if not (lat and lon):
        raise ValueError("Coordenadas no encontradas")
    return float(lat.group(1)), float(lon.group(1))

def extract_merchant_id(url: str) -> str:
    return url.rstrip("/").split("/")[-1]

def get_coords(url: str) -> Tuple[str, float, float]:
    html = descargar_html(url)
    lat, lon = extraer_coordenadas(html)
    return extract_merchant_id(url), lat, lon

if __name__ == "__main__":
    u = sys.argv[1] if len(sys.argv) > 1 else input("URL: ").strip()
    mid, la, lo = get_coords(u)
    print(mid, la, lo)