#!/usr/bin/env python3
# 02_descargar_imagenes_olaclick.py

import os, re, json, argparse
from pathlib import Path
import pandas as pd
import requests

def log(msg: str, logfile: Path) -> None:
    try:
        print(msg)
    except UnicodeEncodeError:
        print(msg.encode("ascii", "ignore").decode())
    logfile.write_text(logfile.read_text("utf-8", errors="ignore")+msg+"\n",
                       encoding="utf-8", errors="ignore")

def safe_filename(txt, maxlen=60):
    return re.sub(r"[^\w\-. ]", "_", txt)[:maxlen]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", required=False)
    ap.add_argument("--out_dir", default="salida")
    ap.add_argument("--limit", type=int, default=0)
    args = ap.parse_args()

    url = args.url or input("URL de la tienda OlaClick: ").strip()
    slug_match = re.search(r"//([a-z0-9\-]+)\.ola\.click", url.lower())
    if not slug_match:
        print("URL de OlaClick no válida."); return
    slug = slug_match.group(1)

    OUT = Path(args.out_dir)/slug
    IMG = OUT/"img";  IMG.mkdir(parents=True, exist_ok=True)
    logf= OUT/"log_02.txt"; logf.touch(exist_ok=True)

    df_prod = pd.read_csv(OUT/"menu_productos_base.csv", encoding="utf-8")
    if args.limit > 0:
        df_prod = df_prod.head(args.limit)

    log(f"Productos a procesar: {len(df_prod)}", logf)

    product_img_paths = {}

    for _, row in df_prod.iterrows():
        prod_id = str(row["product_id"])
        name = str(row["product_name"])
        img_url = row.get("api_image_url")
        if not img_url or not isinstance(img_url, str): continue
        ext = os.path.splitext(img_url)[1].split("?")[0] or ".jpg"
        dst = IMG / f"{safe_filename(prod_id+'_'+name)}{ext}"
        try:
            r = requests.get(img_url, headers={"User-Agent": "Mozilla/5.0"}, timeout=30)
            r.raise_for_status()
            dst.write_bytes(r.content)
            product_img_paths[prod_id] = str(dst)
        except Exception:
            log(f"[WARN] Falló descarga img {prod_id} ({img_url})", logf)

    # Opciones (toppings)
    opc_img_paths = {}
    opt_csv = OUT/"menu_opciones_base.csv"
    if opt_csv.exists():
        df_opt = pd.read_csv(opt_csv, encoding="utf-8")
        for _, row in df_opt.iterrows():
            option_id = str(row["option_id"])
            name = str(row.get("option_name", ""))
            img_url = row.get("option_image_url")
            if not img_url or not isinstance(img_url, str): continue
            ext = os.path.splitext(img_url)[1].split("?")[0] or ".jpg"
            dst = IMG / f"{safe_filename('opc_'+option_id+'_'+name)}{ext}"
            try:
                r = requests.get(img_url, headers={"User-Agent": "Mozilla/5.0"}, timeout=30)
                r.raise_for_status()
                dst.write_bytes(r.content)
                opc_img_paths[option_id] = str(dst)
            except Exception:
                log(f"[WARN] Falló descarga img opción {option_id}", logf)

    (OUT/"paths_img.json").write_text(json.dumps(product_img_paths, ensure_ascii=False, indent=2), encoding="utf-8")
    (OUT/"paths_img_opciones.json").write_text(json.dumps(opc_img_paths, ensure_ascii=False, indent=2), encoding="utf-8")

    log("Script 02_descargar_imagenes_olaclick finalizado.\n", logf)

if __name__ == "__main__":
    main()