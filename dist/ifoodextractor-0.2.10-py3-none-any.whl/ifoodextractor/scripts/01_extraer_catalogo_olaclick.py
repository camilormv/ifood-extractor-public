#!/usr/bin/env python3
# 01_extraer_catalogo_olaclick.py

import argparse
import requests
import re
import json
from pathlib import Path
import pandas as pd
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright

# --- Extracción método 1: HTML directo ---
def extract_company_id_from_html(url: str) -> str | None:
    print("Buscando company_id en el HTML...")
    headers = {'User-Agent': 'Mozilla/5.0'}
    resp = requests.get(url, headers=headers)
    if resp.status_code != 200:
        print(f"Error accediendo a {url}: {resp.status_code}")
        return None

    pat = re.compile(r'ms-products/public/companies/([a-f0-9\-]{36})/categories', re.I)
    m = pat.search(resp.text)
    if m:
        print(f"company_id encontrado por URL endpoint: {m.group(1)}")
        return m.group(1)
    m2 = re.search(r'company_id[^a-f0-9]{0,10}([a-f0-9\-]{36})', resp.text, re.I)
    if m2:
        print(f"company_id encontrado por variable: {m2.group(1)}")
        return m2.group(1)

    soup = BeautifulSoup(resp.text, "html.parser")
    for script in soup.find_all("script"):
        script_content = script.string or ""
        m3 = pat.search(script_content)
        if m3:
            print(f"company_id encontrado en script: {m3.group(1)}")
            return m3.group(1)
        m4 = re.search(r'companyId[^a-f0-9]{0,10}([a-f0-9\-]{36})', script_content, re.I)
        if m4:
            print(f"company_id encontrado en script variable: {m4.group(1)}")
            return m4.group(1)
    print("No se encontró company_id en el HTML.")
    return None

# --- Extracción método 2: Playwright ---
def extract_company_id_playwright(url: str) -> str | None:
    print("Intentando extraer company_id usando Playwright (navegador)...")
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page()
        company_id = None

        def on_request(request):
            nonlocal company_id
            m = re.search(r'/companies/([a-f0-9\-]{36})/categories', request.url)
            if m and not company_id:
                company_id = m.group(1)
                print(f"[Playwright] company_id detectado: {company_id}")

        page.on("request", on_request)
        try:
            page.goto(url, timeout=30000, wait_until="networkidle")
            page.wait_for_timeout(3000)  # Espera requests AJAX
        finally:
            browser.close()
        if not company_id:
            print("[Playwright] No se pudo extraer el company_id.")
        return company_id

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--url", required=True)
    p.add_argument("--out_dir", default="salida")
    args = p.parse_args()

    url = args.url
    slug_match = re.search(r"//([a-z0-9\-]+)\.ola\.click", url.lower())
    if not slug_match:
        print("URL no válida de OlaClick.")
        exit(1)
    slug = slug_match.group(1)

    # --- Extracción AUTOMÁTICA de company_id ---
    company_id = extract_company_id_from_html(url)
    if not company_id:
        company_id = extract_company_id_playwright(url)
    if not company_id:
        print("\n*** ERROR: No se pudo obtener el company_id automáticamente.")
        print("Por favor, utilice DevTools y búsquelo manualmente.")
        exit(1)

    OUT_BASE = Path(args.out_dir).expanduser().resolve()
    OUT_DIR = OUT_BASE / slug
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    logfile = OUT_DIR / "log_01.txt"

    # --- Obtiene catálogo desde company_id ---
    api_url = f"https://public-api.olaclick.app/ms-products/public/companies/{company_id}/categories"
    headers = {
        'accept': "application/json, text/plain, */*",
        'origin': f"https://{slug}.ola.click",
        'referer': f"https://{slug}.ola.click/",
        'user-agent': "Mozilla/5.0"
    }
    resp = requests.get(api_url, headers=headers)
    if resp.status_code != 200:
        print(f"Error consultando API: {resp.status_code}")
        print(resp.text)
        exit(1)
    try:
        catalog = resp.json()
    except Exception as e:
        print(f"Respuesta no es JSON válida: {e}. Texto recibido: '{resp.text[:200]}'")
        exit(1)

    (OUT_DIR / "catalog_raw.json").write_text(json.dumps(catalog, indent=2, ensure_ascii=False), encoding="utf-8")

    with (OUT_DIR / "info_negocio.txt").open("w", encoding="utf-8") as f:
        f.write(f"olaclick_slug: {slug}\n")
        f.write(f"company_id:   {company_id}\n")
        f.write(f"url: {url}\n")

    rows_prod, rows_opt = [], []
    for category in catalog.get("data", []):
        cat_id = category.get("id")
        cat_name = category.get("name")
        for prod in category.get("products", []):
            main_img_url = ""
            if isinstance(prod.get("images"), list) and len(prod["images"]) > 0:
                main_img_url = prod["images"][0].get("image_url") or prod["images"][0].get("image")
            rows_prod.append({
                "category_id": cat_id,
                "category": cat_name,
                "product_id": prod.get("id"),
                "product_name": prod.get("name"),
                "details": prod.get("description"),
                "price": prod.get("price"),
                "api_image_url": main_img_url
            })
            modifier_categories = prod.get("modifier_categories", [])
            for topping in modifier_categories:
                group_name = topping.get("name")
                for option in topping.get("modifiers", []):
                    rows_opt.append({
                        "product_id": prod.get("id"),
                        "product_name": prod.get("name"),
                        "group": group_name,
                        "option_id": option.get("id"),
                        "option_name": option.get("name"),
                        "option_price": option.get("price"),
                        "option_image_url": None
                    })

    pd.DataFrame(rows_prod).to_csv(OUT_DIR / "menu_productos_base.csv", index=False)
    if rows_opt:
        pd.DataFrame(rows_opt).to_csv(OUT_DIR / "menu_opciones_base.csv", index=False)

    print("01_extraer_catalogo_olaclick.py completado")

if __name__ == "__main__":
    main()