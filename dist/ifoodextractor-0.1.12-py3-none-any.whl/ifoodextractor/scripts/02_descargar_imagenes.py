#!/usr/bin/env python3
# 02_descargar_imagenes.py  – versión Playwright-only
# -------------------------------------------------------------------
# • Compatible con Streamlit Community Cloud u otros entornos sin sudo
# • Instala Chromium en una carpeta local (playwright-browsers)
# -------------------------------------------------------------------

import os
import re
import json
import time
import argparse
import sys
import subprocess
from pathlib import Path
from urllib.parse import urljoin

import pandas as pd
import requests
from playwright.sync_api import sync_playwright, Error

# ────────────────────────── Configuración Playwright ────────────────
# Si el loader público (streamlit_app.py) ya definió la variable,
# respetamos esa ubicación; si no, usamos una carpeta local al paquete.
# if "PLAYWRIGHT_BROWSERS_PATH" not in os.environ:
#    LOCAL_BROWSER_DIR = Path(__file__).resolve().parent / "playwright-browsers"
#    os.environ["PLAYWRIGHT_BROWSERS_PATH"] = LOCAL_BROWSER_DIR.as_posix()
#    LOCAL_BROWSER_DIR.mkdir(parents=True, exist_ok=True)

# ──────────────────────── Constantes / helpers ──────────────────────
IFOOD_CDN = "https://static.ifood-static.com.br"


def log(msg: str, logfile: Path) -> None:
    try:
        print(msg)
    except UnicodeEncodeError:
        print(msg.encode("ascii", "ignore").decode())
    logfile.write_text(
        logfile.read_text(encoding="utf-8", errors="ignore") + msg + "\n",
        encoding="utf-8",
        errors="ignore",
    )


def extract_merchant_id(url: str) -> str | None:
    m = re.search(r"([a-f0-9\-]{36})(?:$|/|\?)", url)
    return m.group(1) if m else None


def fix_ifood_url(u: str | None) -> str | None:
    if not u or not isinstance(u, str):
        return None
    if u.startswith("http"):
        return u
    if u.startswith("//"):
        return "https:" + u
    if u.startswith("/"):
        return urljoin(IFOOD_CDN, u.lstrip("/"))
    return urljoin(IFOOD_CDN + "/", u)


def download_image(img_url: str, local_path: Path, timeout: int = 30) -> bool:
    try:
        r = requests.get(img_url, headers={"User-Agent": "Mozilla/5.0"}, timeout=timeout)
        r.raise_for_status()
        local_path.write_bytes(r.content)
        return True
    except Exception:
        return False


def safe_filename(txt: str, maxlen: int = 60) -> str:
    return re.sub(r"[^\w\-. ]", "_", txt)[:maxlen]


# ───────────────────────────── main ─────────────────────────────────
def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--url", required=False, help="URL de la tienda iFood")
    parser.add_argument("--out_dir", default="salida",
                        help="Carpeta base donde se guardarán los resultados")
    parser.add_argument("--limit", type=int, default=0,
                        help="Procesar sólo los primeros N productos (0 = todos)")
    parser.add_argument("--headless", action="store_true",
                        help="Ejecutar Chromium en modo headless")
    args = parser.parse_args()

    url = args.url or input("URL del restaurante iFood: ").strip()
    merchant_id = extract_merchant_id(url)
    if not merchant_id:
        print("merchant_id no encontrado en la URL.")
        return

    # ----------------── carpetas / ficheros --------------------------
    OUT_DIR = Path(args.out_dir) / merchant_id
    IMG_DIR = OUT_DIR / "img"
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    IMG_DIR.mkdir(exist_ok=True)
    logfile = OUT_DIR / "log_02.txt"
    logfile.touch(exist_ok=True)

    prod_csv = OUT_DIR / "menu_productos_base.csv"
    opt_csv  = OUT_DIR / "menu_opciones_base.csv"
    if not prod_csv.exists():
        print("Falta menu_productos_base.csv. Ejecuta antes 01_extraer_catalogo.py")
        return

    df_prod = pd.read_csv(prod_csv, encoding="utf-8")
    df_opt  = pd.read_csv(opt_csv,  encoding="utf-8") if opt_csv.exists() else pd.DataFrame()

    if args.limit > 0:
        df_prod = df_prod.head(args.limit)
        if not df_opt.empty:
            ids_keep = set(df_prod["product_id"])
            df_opt = df_opt[df_opt["product_id"].isin(ids_keep)]

    log(f"Productos a procesar: {len(df_prod)}", logfile)

    product_img_paths: dict[str, str] = {}
    opcion_img_paths:  dict[str, str] = {}

    # ----------------── Playwright scraping -------------------------
    log("-> Lanzando Playwright / Chromium …", logfile)
    with sync_playwright() as pw:
        # Intentamos lanzar Chromium; si no existe, lo instalamos
        try:
            browser = pw.chromium.launch(headless=args.headless)
        except Error as e:
            if "Executable doesn't exist" in str(e):
                log("Chromium no encontrado. Descargando …", logfile)
                subprocess.check_call([sys.executable, "-m", "playwright", "install", "chromium"])
                browser = pw.chromium.launch(headless=args.headless)
            else:
                raise

        page = browser.new_page()
        page.goto(url, timeout=60_000)
        page.wait_for_timeout(8_000)

        # scroll para cargar todos los platos
        for _ in range(12):
            page.mouse.wheel(0, 6000)
            page.wait_for_timeout(1000)

        cards = page.query_selector_all('li[data-test-id="restaurant-menu-group-item"]')
        log(f"Tarjetas detectadas: {len(cards)}", logfile)

        for card in cards:
            try:
                name_node = card.query_selector('.dish-card__info')
                if not name_node:
                    continue
                name = name_node.inner_text().split('\n')[0].strip()

                img_node = card.query_selector('div.dish-card__container-image img')
                if not img_node:
                    continue
                img_url = fix_ifood_url(img_node.get_attribute("src"))
                if not img_url:
                    continue

                prod_match = df_prod[df_prod["product_name"] == name]
                if prod_match.empty:
                    continue

                code = str(prod_match.iloc[0]["product_code"])
                ext  = os.path.splitext(img_url)[1].split("?")[0] or ".jpg"
                local_path = IMG_DIR / f"{safe_filename(code+'_'+name)}{ext}"

                if download_image(img_url, local_path):
                    product_img_paths[code] = str(local_path)
                    log(f"OK  {code}", logfile)
            except Exception as e:
                log(f"[ERR] tarjeta: {e}", logfile)

        browser.close()

    # ----------------------------------------------------------------
    # Guardar resultados
    # ----------------------------------------------------------------
    (OUT_DIR / "paths_img.json").write_text(
        json.dumps(product_img_paths, ensure_ascii=False, indent=2), encoding="utf-8")

    (OUT_DIR / "paths_img_opciones.json").write_text(
        json.dumps(opcion_img_paths, ensure_ascii=False, indent=2), encoding="utf-8")

    log(f"Imágenes productos : {len(product_img_paths)}", logfile)
    log("Script 02_descargar_imagenes finalizado.\n", logfile)


if __name__ == "__main__":
    main()